# Banking System in Core Java

Open terminal Compile and run java Splash file
